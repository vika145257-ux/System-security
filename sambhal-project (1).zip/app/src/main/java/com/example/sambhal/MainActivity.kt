package com.example.sambhal

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        val list = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_list_item_multiple_choice,
                apps.map { it.first }
            )
        }
        val selected = Prefs.getApps(this)
        apps.forEachIndexed { i, a -> list.setItemChecked(i, a.second in selected) }
        list.setOnItemClickListener { _, _, _, _ ->
            val chosen = apps.indices.filter { list.isItemChecked(it) }.map { apps[it].second }
            Prefs.setApps(this, chosen.toSet())
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 24)
        }
        status = TextView(this).apply { textSize = 16f }
        root.addView(status)
        root.addView(TextView(this).apply {
            textSize = 14f
            text = "जिन ऐप्स पर वीडियो चलाना है, उन्हें टिक करो:"
            setPadding(0, 16, 0, 8)
        })
        root.addView(Switch(this).apply {
            text = "वीडियो के बाद ऐप बंद करो (होम पर भेजो)"
            isChecked = Prefs.goHome(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setGoHome(this@MainActivity, v) }
        })
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        // नीचे सेटिंग / परमिशन बटन
        root.addView(Button(this).apply {
            text = "⚙ सेटिंग / परमिशन दो"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "ऊपर दिखने की परमिशन (Display over other apps)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "ऐप इन्फो (Restricted settings के लिए)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")))
            }
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val svc = BlockerService.instance != null
        val ov = Settings.canDrawOverlays(this)
        status.text = (if (svc) "✅ Sambhal चालू है" else "❌ Sambhal बंद है (सेटिंग बटन से ON करो)") +
            "\n" + (if (ov) "✅ ओवरले परमिशन मिल गई" else "❌ ओवरले परमिशन नहीं मिली")
    }
}
