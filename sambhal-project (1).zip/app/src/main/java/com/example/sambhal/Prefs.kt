package com.example.sambhal

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("sambhal", Context.MODE_PRIVATE)

    fun getApps(c: Context): Set<String> =
        sp(c).getStringSet("apps", emptySet()) ?: emptySet()

    fun setApps(c: Context, apps: Set<String>) =
        sp(c).edit().putStringSet("apps", HashSet(apps)).apply()

    fun goHome(c: Context): Boolean = sp(c).getBoolean("goHome", true)

    fun setGoHome(c: Context, v: Boolean) =
        sp(c).edit().putBoolean("goHome", v).apply()
}
