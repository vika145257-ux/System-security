package com.example.sambhal

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.VideoView

class VideoActivity : Activity() {

    private var completed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isShowing = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_video)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        // स्क्रीन पर कहीं भी उंगली लगाओ, कुछ नहीं होगा (टच पूरी तरह जाम)
        findViewById<View>(R.id.root).setOnTouchListener { _, _ -> true }

        val video = findViewById<VideoView>(R.id.video)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.motivation}"))
        video.setOnCompletionListener {
            completed = true
            BlockerService.instance?.onVideoDone()
            finish()
        }
        video.start()
    }

    // बैक बटन बंद
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { }

    // अगर कोई Home दबाकर या स्क्रीन लॉक करके वीडियो अधूरा छोड़े,
    // तो सीधा होम पर भेज दो, ताकि ऐप बिना वीडियो देखे दिखे ही नहीं
    override fun onStop() {
        super.onStop()
        isShowing = false
        if (!completed) {
            BlockerService.instance?.abortToHome()
            finish()
        }
    }

    override fun onDestroy() {
        isShowing = false
        super.onDestroy()
    }

    companion object {
        @Volatile var isShowing = false
    }
}
