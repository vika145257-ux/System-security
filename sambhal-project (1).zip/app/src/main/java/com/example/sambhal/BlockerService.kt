package com.example.sambhal

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class BlockerService : AccessibilityService() {

    private var ignoreUntil = 0L
    private var lastPkg = ""

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // अपना ऐप, सिस्टम UI और कीबोर्ड को अनदेखा करो
        if (pkg == packageName || pkg == "com.android.systemui" ||
            pkg.contains("inputmethod") || pkg.contains("keyboard")) return

        val changed = pkg != lastPkg
        lastPkg = pkg
        if (!changed) return                       // उसी ऐप के अंदर दोबारा नहीं
        if (VideoActivity.isShowing) return
        if (System.currentTimeMillis() < ignoreUntil) return

        // सिर्फ़ चुने हुए ऐप्स पर वीडियो (होम स्क्रीन पर कभी नहीं)
        if (pkg !in Prefs.getApps(this)) return

        startActivity(Intent(this, VideoActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // वीडियो खत्म होने पर
    fun onVideoDone() {
        ignoreUntil = System.currentTimeMillis() + 2000
        if (Prefs.goHome(this)) performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // वीडियो अधूरा छूटा -> होम पर भेजो
    fun abortToHome() {
        lastPkg = ""
        ignoreUntil = System.currentTimeMillis() + 1500
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        var instance: BlockerService? = null
    }
}
